<?php
    $title = "Comptes";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template starter-template-comptes">
    <h1>Gestion de la Base de données</h1>
    <div class="container-form">
        <div class="list-group" id="bdd-list">
            <div class="alert alert-success" role="alert">
                <strong>INFORMATION: </strong>Le fichier exporté sera sauvegardé sur le serveur.
            </div>
            <a class="list-group-item active" href="">Exportation</a>
            <a class="list-group-item list-group-item-action" href="./index.php?action=bddE&type=1">Structure</a>
            <a class="list-group-item list-group-item-action" href="./index.php?action=bddE&type=2">Données</a>
            <a class="list-group-item list-group-item-action" href="./index.php?action=bddE&type=3">Structure et Données</a>
        </div>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
