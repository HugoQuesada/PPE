
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="public/images/favicon.ico"/>

    <title><?= $title ?></title>

    <!-- Bootstrap core CSS -->
    <link href="./public/css/bootstrap.min.css" rel="stylesheet">
    <link href="./public/css/index.css" rel="stylesheet">
    <link href="./public/css/datatable.css" rel="stylesheet">
  </head>

  <body>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top">
      <a class="navbar-brand" href="">Stage v3</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#nav" aria-controls="nav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="nav">
        <?= $menu ?>
      </div>
    </nav>

    <main role="main" class="container">
      <?= $content ?>
    </main>
    <footer class="footer">
      <div class="container">
        <span class="text-muted">Ce site est la propriété du Lycée du Grand Noumea</span>
        <div class="container-img-footer">
          <img class="img-footer" src="./public/images/footer1.png" alt="Logo du Grand Noumea">
          <img class="img-footer" src="./public/images/footer2.png" alt="Logo du BTS Sio">
        </div>
      </div>
    </footer>
    <script>window.jQuery || document.write('<script src="./public/js/jquery.min.js"><\/script>')</script>
    <script src="./public/js/popper.min.js"></script>
    <script src="./public/js/tether.min.js"></script>
    <script src="./public/js/bootstrap.min.js"></script>
    <script src="./public/js/ie10-viewport-bug-workaround.js"></script>
    <script src="./public/js/jquery.datatable.js"></script>
		<script type="text/javascript">
      $(document).ready(function() {
        $('#table').DataTable();
      });
		</script>
  </body>
</html>
