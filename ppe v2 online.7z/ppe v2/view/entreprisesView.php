<?php
    $title = "Entreprises";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item active dropdown show">
        <a class="nav-link dropdown-toggle" href="" id="dropdownEntreprise" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Entreprises</a>
        <div class="dropdown-menu" aria-labelledby="dropdownEntreprise">
            <a class="dropdown-item" href="./index.php?action=addEntrepriseForm">Ajout d'une entreprise</a>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Entreprises</h1>
    <div class="table-view">
        <table id="table" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Raison Sociale</th>
                <th>Adresse</th>
                <th>Mobile</th>
                <th>Horaires</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($data = $req->fetch()){
                    echo('<tr class="tr-cursor" onclick="document.location=\'./index.php?action=viewEntreprise&id=' . $data['id'] . '\'">
                        <td>' . ucwords(mb_strtolower($data['rs'])) . '</td>
                        <td>' . $data['adresse'] . '</td>
                        <td>' . $data['mobile'] . '</td>
                        <td>' . $data['horaires'] . '</td>
                    </tr>');
                }
            ?>
        </tbody>
        </table>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
