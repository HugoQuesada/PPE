<?php
    $title = "Stages";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item dropdown show">
        <a class="nav-link dropdown-toggle" href="" id="dropdownStage" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Stages</a>
        <div class="dropdown-menu" aria-labelledby="dropdownStage">
            <a class="dropdown-item" href="./index.php?action=addStageForm">Ajout d'un stages</a>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item active dropdown show">
              <a class="nav-link dropdown-toggle" href="" id="dropdownEntreprise" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Administration</a>
              <div class="dropdown-menu" aria-labelledby="dropdownEntreprise">
                  <a class="dropdown-item" href="./index.php?action=addUserForm">Ajout d\'un utilisateur</a>
                  <a class="dropdown-item" href="./index.php?action=updtUserForm">Modification d\'un utilisateur</a>
                  <a class="dropdown-item" href="./index.php?action=activeUserForm">Activer un utilisateur</a>
                  <a class="dropdown-item" href="./index.php?action=delUserForm">Désactiver un utilisateur</a>
              </div>
          </li>');
        }
      }
    ?>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Administration</h1>
    <h5>Liste des utilisateurs</h5>
    <div class="table-view">
        <table id="table" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Identité</th>
                <th>Mail</th>
                <th>Mobile</th>
                <th>Actif</th>
                <th>Statut</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($data = $req->fetch()){
                    echo('<tr class="tr-cursor" onclick="document.location=\'./index.php?action=updtUserForm&id=' . $data['id'] . '\'">
                        <td>' . ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom'])) . '</td>
                        <td>' . $data['mail'] . '</td>
                        <td>' . $data['mobile'] . '</td>
                        <td>' . (($data['actif']) ? 'Oui' : 'Non') . '</td>
                        <td>' . ucwords(mb_strtolower($data['statut'])) . '</td>
                    </tr>');
                }
            ?>
        </tbody>
        </table>
    </div>
    <h5>Informations sur le site:</h5>
    <table class="table">
      <thead class="thead-dark">
        <tr>
          <th scope="col">Table</th>
          <th scope="col">Nombre d'entrée</th>
          <th scope="col">Nombre actif</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th scope="row">Utilisateurs</th>
          <td><?= $infos['users']; ?></td>
          <td><?= $infosActif['users']; ?></td>
        </tr>
        <tr>
          <th scope="row">Entreprises</th>
          <td><?= $infos['entreprises']; ?></td>
          <td><?= $infosActif['entreprises']; ?></td>
        </tr>
        <tr>
          <th scope="row">Etudiants</th>
          <td><?= $infos['etudiants']; ?></td>
          <td><?= $infosActif['etudiants']; ?></td>
        </tr>
        <tr>
          <th scope="row">Maitre de stages</th>
          <td><?= $infos['mds']; ?></td>
          <td><?= $infosActif['mds']; ?></td>
        </tr>
        <tr>
          <th scope="row">Responsables</th>
          <td><?= $infos['responsables']; ?></td>
          <td><?= $infosActif['responsables']; ?></td>
        </tr>
        <tr>
          <th scope="row">Stages</th>
          <td><?= $infos['stages']; ?></td>
          <td><?= $infosActif['stages']; ?></td>
        </tr>
      </tbody>
    </table>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
