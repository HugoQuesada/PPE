<?php
    $title = "Maitres de stages";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item active dropdown show">
        <a class="nav-link dropdown-toggle" href="" id="dropdownMds" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Maitres de stages</a>
        <div class="dropdown-menu" aria-labelledby="dropdownMds">
            <a class="dropdown-item" href="./index.php?action=addMdsForm">Ajout d'un maitre de stages</a>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Maitres de stages</h1>
    <div class="table-view">
        <table id="table" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Identité</th>
                <th>Entreprise</th>
                <th>Mobile</th>
                <th>Mail</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($data = $req->fetch()){
                    echo('<tr class="tr-cursor" onclick="document.location=\'./index.php?action=viewMds&id=' . $data['id'] . '\'">
                        <td>' . ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom'])) . '</td>
                        <td>' . $entreprises[$mdsEntreprises[$data['id']]] . '</td>
                        <td>' . $data['mobile'] . '</td>
                        <td>' . $data['mail'] . '</td>
                    </tr>');
                }
                while($data = $req2->fetch()){
                    echo('<tr class="tr-cursor" onclick="document.location=\'./index.php?action=viewResponsable&id=' . $data['id'] . '&redirect=viewMDS\'">
                        <td>' . ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom'])) . '</td>
                        <td>' . $entreprises[$mdsRespEntreprises[$data['id']]] . '</td>
                        <td>' . $data['mobile'] . '</td>
                        <td>' . $data['mail'] . '</td>
                    </tr>');
                }
            ?>
        </tbody>
        </table>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
