<?php session_start();
    date_default_timezone_set("Pacific/Noumea");
    require("./controler/comptes.php");
    require("./controler/connexion.php");
    require("./controler/entreprises.php");
    require("./controler/etudiants.php");
    require("./controler/home.php");
    require("./controler/mds.php");
    require("./controler/responsables.php");
    require("./controler/stages.php");
    require("./controler/tests.php");
    require("./controler/bdd.php");
    require("./controler/graph.php");
    require("./controler/administration.php");
    try{
        //Verification connexion
        $connect = false;
        if(isset($_SESSION['connect'])){
            if($_SESSION['connect'] == true){
                $connect = true;
            }
        }
        //Actions
        $default = true;
        if(isset($_GET['action'])){
            $action = $_GET['action'];
            //redirect
            if(isset($_SESSION['redirect']) and isset($_SESSION['redirect_compt'])){
              if($_SESSION['redirect'] != null and $_SESSION['redirect_compt'] == 0){
                $action = $_SESSION['redirect'];
                unset($_SESSION['redirect']);
                unset($_SESSION['redirect_compt']);
              }else if($_SESSION['redirect_compt'] > 0){
                $_SESSION['redirect_compt']--;
              }
            }
            if(!$connect){ //Seuls actions possibles si pas connecté
                if($action == "connect"){
                    if(isset($_POST)){
                        if(!empty($_POST['username']) and !empty($_POST['password'])){
                            if(connect($_POST['username'], $_POST['password'])){//La fonction return true si la connexion est OK
                                $connect = true;
                            }
                        }
                    }
                }
            }else{//Actions possibles si connecté
                if($action == "deconnect"){
                    deconnect();
                    $connect = false;
                }else if($action == "viewStages"){//Les differentes View
                    viewStages();
                    $default = false;
                }else if($action == "viewEntreprises"){
                    viewEntreprises();
                    $default = false;
                }else if($action == "viewMDS"){
                    viewMds();
                    $default = false;
                }else if($action == "viewEtudiants"){
                    viewEtudiants();
                    $default = false;
                }else if($action == "viewResponsables"){
                    viewResponsables();
                    $default = false;
                }else if($action == "account"){
                    viewComptes();
                    $default = false;
                }else if($action == "bdd"){
                    viewBdd();
                    $default = false;
                }else if($action == "bddE"){
                    if(isset($_GET['type'])){
                        if($_GET['type'] >= 1 and $_GET['type'] <= 3){
                            dumpBdd($_GET['type']);
                            $default = false;
                        }
                    }
                    if($default){
                        viewBdd();
                        $default = false;
                    }
                }else if($action == "graph" and !isset($_GET['type'])){
                    viewGraph();
                    $default = false;
                }else if($action == "graph" and isset($_GET['type'])){
                    if($_GET['type'] >= 1 and $_GET['type'] <= 7){
                        switch($_GET['type']){
                            case 1:
                                graphAll();
                                $default = false;
                            break;
                            case 2:
                                if(isset($_POST['year'])){
                                    graphYear($_POST['year']);
                                    $default = false;
                                }
                            break;
                            case 3:
                                if(isset($_POST['option'])){
                                    graphOption($_POST['option']);
                                    $default = false;
                                }
                            break;
                            case 4:
                                if(isset($_POST['year']) and isset($_POST['option'])){
                                    graphYearOption($_POST['year'], $_POST['option']);
                                    $default = false;
                                }
                            break;
                            case 5:
                                if($_POST['promo']){
                                    graphPromo($_POST['promo']);
                                    $default = false;
                                }
                            break;
                            case 6:
                                if(isset($_POST['promo']) and isset($_POST['year'])){
                                    graphPromoYear($_POST['promo'], $_POST['year']);
                                    $default = false;
                                }
                            break;
                            case 7:
                                if(isset($_POST['promo']) and isset($_POST['option'])){
                                    graphPromoOption($_POST['promo'], $_POST['option']);
                                    $default = false;
                                }
                            break;
                        }
                    }
                    if($default){
                        viewGraph();
                        $default = false;
                    }
                }else if($action == "viewStage"){//Les differentes View affiche 1 seul
                    if(isset($_GET['id'])){
                        if(!empty($_GET['id'])){
                            viewStage($_GET['id']);
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        viewStages();
                    }
                }else if($action == "viewEntreprise"){
                    if(isset($_GET['id'])){
                        if(!empty($_GET['id'])){
                            viewEntreprise($_GET['id']);
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        viewEntreprises();
                    }
                }else if($action == "viewMds"){
                    if(isset($_GET['id'])){
                        if(!empty($_GET['id'])){
                            viewMdsOne($_GET['id']);
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        viewMds();
                    }
                }else if($action == "viewEtudiant"){
                    if(isset($_GET['id'])){
                        if(!empty($_GET['id'])){
                            if(issetEtudiant($_GET['id'])){
                                viewEtudiant($_GET['id']);
                                $default = false;
                            }
                        }
                    }
                    if($default){
                        $default = false;
                        viewEtudiants();
                    }
                }else if($action == "viewResponsable"){
                    if(isset($_GET['id'])){
                        if(!empty($_GET['id'])){
                            viewResponsable($_GET['id']);
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        viewResponsables();
                    }
                }else if($action == "addStageForm"){//Les formulaires d'ajouts
                    addStageForm();
                    $default = false;
                }else if($action == "addEntrepriseForm"){
                    addEntrepriseForm();
                    $default = false;
                }else if($action == "addMdsForm"){
                    addMdsForm();
                    $default = false;
                }else if($action == "addEtudiantForm"){
                    addEtudiantForm();
                    $default = false;
                }else if($action == "addResponsableForm"){
                    addResponsableForm();
                    $default = false;
                }else if($action == "addStage"){//Le traitement des formulaires d'ajouts
                    if(isset($_POST)){
                        if(!empty($_POST['etudiant']) and !empty($_POST['mds']) and !empty($_POST['dateDebut']) and !empty($_POST['dateFin'])){
                            $etudiantId = getEtudiantId(mb_strtolower($_POST['etudiant']));
                            $mdsId = getMdsId(mb_strtolower($_POST['mds']));
                            (empty($_POST['commentaire']))? $commentaire = "Il n'y a pas de commentaire..." : $commentaire = $_POST['commentaire'];
                            addStage($etudiantId, $mdsId, mb_strtolower($_POST['dateDebut']), mb_strtolower($_POST['dateFin']), $commentaire);
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        addStageForm();
                    }
                }else if($action == "addEntreprise"){
                    if(isset($_POST)){
                        if(!empty($_POST['rs']) and !empty($_POST['adresse']) and !empty($_POST['mobile'])){
                            if(testMobile($_POST['mobile'])){
                                if(!existEntreprise(mb_strtolower($_POST['rs']))){
                                    (empty($_POST['description']))? $desc = "Il n'y a pas de description" : $desc = $_POST['description'];
                                    (empty($_POST['horaires']))? $horaires = "Les horaires ne sont pas précisés" : $horaires = ucfirst(mb_strtolower($_POST['horaires']));
                                    addEntreprise(mb_strtolower($_POST['rs']), $_POST['mobile'], mb_strtolower($_POST['adresse']), mb_strtolower($horaires), $desc);
                                    $default = false;
                                }else{
                                    (empty($_POST['description']))? $desc = "Il n'y a pas de description" : $desc = $_POST['description'];
                                    (empty($_POST['horaires']))? $horaires = "Les horaires ne sont pas précisés" : $horaires = ucfirst(mb_strtolower($_POST['horaires']));
                                    activeEntreprise(mb_strtolower($_POST['rs']), $_POST['mobile'], mb_strtolower($_POST['adresse']), mb_strtolower($horaires), $desc);
                                    $default = false;
                                }
                            }
                        }else if(!empty($_POST['rs']) and empty($_POST['adresse']) and empty($_POST['mobile']) and empty($_POST['horaires']) and empty($_POST['description'])){
                            activatedEntreprise(mb_strtolower($_POST['rs']));
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        addEntrepriseForm();
                    }
                }else if($action == "addMds"){
                    if(isset($_POST)){
                        if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['mail']) and !empty($_POST['mobile']) and !empty($_POST['entreprise'])){
                            if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                if(!existMds(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']))){
                                    $entrepriseId = getEntrepriseId(mb_strtolower($_POST['entreprise']));
                                    addMds(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), $entrepriseId);
                                    $default = false;
                                }else{
                                    $entrepriseId = getEntrepriseId(mb_strtolower($_POST['entreprise']));
                                    activeMds(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), $entrepriseId);
                                    $default = false;
                                }
                            }
                        }else if(!empty($_POST['nom']) and !empty($_POST['prenom']) and empty($_POST['mail']) and empty($_POST['mobile']) and empty($_POST['entreprise'])){
                            activatedMds(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']));
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        addMdsForm();
                    }
                }else if($action == "addEtudiant"){
                    if(isset($_POST)){
                        if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['option']) and !empty($_POST['mail']) and !empty($_POST['mobile']) and !empty($_POST['promo'])){
                            if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                if(!existEtudiant(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']))){
                                    addEtudiant(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['option']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), mb_strtolower($_POST['promo']));
                                    $default = false;
                                }else{
                                    activeEtudiant(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['option']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), mb_strtolower($_POST['promo']));
                                    $default = false;
                                }
                            }
                        }else if(!empty($_POST['nom']) and !empty($_POST['prenom']) and empty($_POST['mail']) and empty($_POST['mobile'])){
                            activatedEtudiant(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']));
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        addEtudiantForm();
                    }
                }else if($action == "addResponsable"){
                    if(isset($_POST)){
                        if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['civilite']) and !empty($_POST['fonction']) and !empty($_POST['mail']) and !empty($_POST['mobile']) and !empty($_POST['entreprise']) and !empty($_POST['estMds'])){
                            if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                if(!existResponsable(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']))){
                                    $entrepriseId = getEntrepriseId(mb_strtolower($_POST['entreprise']));
                                    addResponsable(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), $_POST['civilite'], mb_strtolower($_POST['fonction']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), $entrepriseId, $_POST['estMds']);
                                    $default = false;
                                }else{
                                    $entrepriseId = getEntrepriseId(mb_strtolower($_POST['entreprise']));
                                    activeResponsable(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), $_POST['civilite'], mb_strtolower($_POST['fonction']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), $entrepriseId, $_POST['estMds']);
                                    $default = false;
                                }
                            }
                        }else if(!empty($_POST['nom']) and !empty($_POST['prenom']) and empty($_POST['fonction']) and empty($_POST['mail']) and empty($_POST['mobile']) and empty($_POST['entreprise'])){
                            activatedResponsable(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']));
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        addResponsableForm();
                    }
                }else if($action == "updtStage"){//Le traitement des formulaires de modifications
                    if(isset($_POST)){
                        if(!empty($_POST['etudiant']) and !empty($_POST['enseignant']) and !empty($_POST['mds']) and !empty($_POST['dateDebut']) and !empty($_POST['dateFin'])){
                            $etudiantId = getEtudiantId(mb_strtolower($_POST['etudiant']));
                            $enseignantId = getEnseignantId(mb_strtolower($_POST['enseignant']));
                            $mdsId = getMdsId(mb_strtolower($_POST['mds']));
                            (empty($_POST['commentaire']))? $commentaire = "Il n'y a pas de commentaire..." : $commentaire = $_POST['commentaire'];
                            updtStage($etudiantId, $enseignantId, $mdsId, mb_strtolower($_POST['dateDebut']), mb_strtolower($_POST['dateFin']), $commentaire, $_POST['id']);
                            $default = false;
                        }
                    }
                    if($default){
                        $default = false;
                        viewStages();
                    }
                }else if($action == "updtEntreprise"){
                    if(isset($_POST)){
                        if(!empty($_POST['rs']) and !empty($_POST['adresse']) and !empty($_POST['mobile'])){
                            if(testMobile($_POST['mobile'])){
                                (empty($_POST['description']))? $desc = "Il n'y a pas de description" : $desc = $_POST['description'];
                                (empty($_POST['horaires']))? $horaires = "Les horaires ne sont pas précisés" : $horaires = ucfirst(mb_strtolower($_POST['horaires']));
                                updtEntreprise($_POST['rs'], $_POST['mobile'], $_POST['adresse'], $horaires, $desc, $_POST['id']);
                                $default = false;
                            }
                        }
                    }
                    if($default){
                        $default = false;
                        viewEntreprises();
                    }
                }else if($action == "updtMds"){
                    if(isset($_POST)){
                        if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['mail']) and !empty($_POST['mobile']) and !empty($_POST['entreprise'])){
                            if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                $entrepriseId = getEntrepriseId(mb_strtolower($_POST['entreprise']));
                                updtMds(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), $entrepriseId, $_POST['id']);
                                $default = false;
                            }
                        }
                    }
                    if($default){
                        $default = false;
                        viewMds();
                    }
                }else if($action == "updtEtudiant"){
                    if(isset($_POST)){
                        if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['option']) and !empty($_POST['mail']) and !empty($_POST['mobile']) and !empty($_POST['promo'])){
                            if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                updtEtudiant(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['option']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), mb_strtolower($_POST['promo']), $_POST['id']);
                                $default = false;
                            }
                        }
                    }
                    if($default){
                        $default = false;
                        viewEtudiants();
                    }
                }else if($action == "updtResponsable"){
                    if(isset($_POST)){
                        if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['civilite']) and !empty($_POST['fonction']) and !empty($_POST['mail']) and !empty($_POST['mobile']) and !empty($_POST['entreprise']) and !empty($_POST['estMds'])){
                            if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                $entrepriseId = getEntrepriseId(mb_strtolower($_POST['entreprise']));
                                updtResponsable(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), $_POST['civilite'], mb_strtolower($_POST['fonction']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), $entrepriseId, $_POST['id'], $_POST['estMds']);
                                $default = false;
                            }
                        }
                    }
                    if($default){
                        $default = false;
                        viewResponsables();
                    }
                }else if($action == "updtCompte"){
                    if(isset($_POST)){
                        if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['mail']) and !empty($_POST['mobile'])){
                            if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                if(!empty($_POST['newpass']) and !empty($_POST['confirmpass']) and !empty($_POST['oldpass'])){
                                    if(checkPass($_POST['oldpass'])){
                                        if($_POST['newpass'] == $_POST['confirmpass']){
                                            updtCompteMDP(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['mail']), $_POST['mobile'], $_POST['newpass']);
                                            $default = false;
                                        }
                                    }
                                }else{
                                    updtCompte(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['mail']), $_POST['mobile']);
                                    $default = false;
                                }
                            }
                        }
                    }
                    if($default){
                        $default = false;
                        viewComptes();
                    }
                }else if($action == "delStage"){//Suppresion
                    if(isset($_GET['id'])){
                        delStage($_GET['id']);
                        $default = false;
                    }
                }else if($action == "delEntreprise"){
                    if(isset($_GET['id'])){
                        delEntreprise($_GET['id']);
                        $default = false;
                    }
                }else if($action == "delMds"){
                    if(isset($_GET['id'])){
                        delMds($_GET['id']);
                        $default = false;
                    }
                }else if($action == "delEtudiant"){
                    if(isset($_GET['id'])){
                        delEtudiant($_GET['id']);
                        $default = false;
                    }
                }else if($action == "delResponsable"){
                    if(isset($_GET['id'])){
                        delResponsable($_GET['id']);
                        $default = false;
                    }
                }else if($action == "admin"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          viewAdministration();
                          $default = false;
                        }
                    }
                }else if($action == "addUserForm"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          addUserForm();
                          $default = false;
                        }
                    }
                }else if($action == "delUserForm"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          delUserForm();
                          $default = false;
                        }
                    }
                }else if($action == "activeUserForm"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          activeUserForm();
                          $default = false;
                        }
                    }
                }else if($action == "updtUserForm"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          if(isset($_GET['id'])){
                            if($_GET['id'] != null){
                              updtUserForm($_GET['id']);
                              $default = false;
                            }
                          }
                        }
                    }
                }else if($action == "addUser"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          if(isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['mail']) and isset($_POST['mobile']) and isset($_POST['pass']) and isset($_POST['statut'])){
                            if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['mail']) and !empty($_POST['mobile']) and !empty($_POST['pass']) and !empty($_POST['statut'])){
                              if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                addUser(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), encodePass($_POST['pass']), mb_strtolower($_POST['statut']));
                                $default = false;
                              }
                            }
                          }
                          viewAdministration();
                        }
                    }
                }else if($action == "delUser"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          if(isset($_GET['id'])){
                            if($_GET['id'] != null){
                              delUser($_GET['id']);
                            }
                          }
                          viewAdministration();
                          $default = false;
                        }
                    }
                }else if($action == "activeUser"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          if(isset($_GET['id'])){
                            if($_GET['id'] != null){
                              activeUser($_GET['id']);
                            }
                          }
                          viewAdministration();
                          $default = false;
                        }
                    }
                }else if($action == "updtUser"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          if(isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['mail']) and isset($_POST['mobile']) and isset($_POST['id']) and isset($_POST['statut'])){
                            if(!empty($_POST['nom']) and !empty($_POST['prenom']) and !empty($_POST['mail']) and !empty($_POST['mobile']) and !empty($_POST['id']) and !empty($_POST['statut'])){
                              if(testMail($_POST['mail']) and testMobile($_POST['mobile'])){
                                updtUser(mb_strtolower($_POST['nom']), mb_strtolower($_POST['prenom']), mb_strtolower($_POST['mail']), mb_strtolower($_POST['mobile']), mb_strtolower($_POST['statut']), $_POST['id']);
                                $default = false;
                              }
                            }
                          }
                          viewAdministration();
                        }
                    }
                }else if($action == "changePasswordUser"){
                    if(isset($_SESSION['admin'])){
                        if($_SESSION['admin'] == true){
                          if(isset($_POST['password'])){
                            if(!empty($_POST['password'])){
                              changePasswordUser(encodePass($_POST['password']), $_POST['id']);
                              $default = false;
                            }
                          }
                          viewAdministration();
                        }
                    }
                }
            }
        }
        //redirect
        if(isset($_GET['redirect']) and isset($_GET['wait'])){
          if($_GET['redirect'] != null){
            $_SESSION['redirect'] = $_GET['redirect'];
            $_SESSION['redirect_compt'] = ($_GET['wait'] != null)? $_GET['wait'] : 1;
          }
        }
        if(!$connect){//Affichage formulaire si pas connecté
            connectForm();
        }else if($default){//Affichage page default si connecté
            home();
        }
    }catch(Exception $e){
        require('view/errorView.php');
    }
