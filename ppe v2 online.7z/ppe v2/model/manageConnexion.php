<?php
    class manageConnexion{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function encode($think){
            return hash('sha256', $think);
        }
        function connect($username, $password){
            $password = $this->encode($password);
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT id, mail, password, actif, statut FROM users');
            $connect = false;
            while($data = $req->fetch()){
                if($username == $data['mail'] and $password == $data['password']){
                    if($data['actif'] == 1){
                        $_SESSION['connect'] = true;
                        $_SESSION['idUser'] = $data['id'];
                        if($data['statut'] == "admin"){
                          $_SESSION['admin'] = true;
                        }
                        $connect = true;
                        $this->saveIntoLog($data['id']);
                    }
                }
            }
            return $connect;
        }
        function deconnect(){
            session_destroy();
        }
        function checkPass($pass){
            $password = $this->encode($pass);
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT id, password FROM users WHERE id = ?');
            $req->execute(array($_SESSION['idUser']));
            $connect = false;
            while($data = $req->fetch()){
                if($password == $data['password']){
                    $connect = true;
                }
            }
            return $connect;
        }
        function saveIntoLog($id){
            $data = "Date: " . date('d:m:Y H:i:s') . " :\r\n";
            $data .= "Ip Adress : " . $_SERVER['REMOTE_ADDR'] . " -> Id of users: " . $id . "\r\n \r\n";
            $fichierDump = fopen("./public/log/LogConnection.txt", "a");
            fwrite($fichierDump, $data);
            fclose($fichierDump);
        }
    }
