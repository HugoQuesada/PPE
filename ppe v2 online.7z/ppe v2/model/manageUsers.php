<?php
    class manageUsers{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function getUsersTab(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM users ORDER BY nom ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom']));
            }
            return $tab;
        }
        function getUsersName(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT nom, prenom FROM users WHERE actif = 1 ORDER BY nom ASC');
            return $req;
        }
        function getUsersId($name){
            $temp = explode(' ', $name);
            $nom = $temp[0];
            $prenom = $temp[1];
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT nom, prenom, id FROM users WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
            while($data = $req->fetch()){$id = $data['id'];}
            return $id;
        }
    }