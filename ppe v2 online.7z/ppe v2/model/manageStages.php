<?php
    class manageStages{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function getStages(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM stages WHERE actif = 1 ');
            return $req;
        }
        function getStage($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT * FROM stages WHERE id = ?');
            $req->execute(array($id));
            return $req;
        }
        function addStage($etudiantId, $mdsId, $dateDebut, $dateFin, $commentaire){
            $bdd = $this->getDb();
            $req = $bdd->prepare('INSERT INTO stages(etudiant, mds, date_debut, date_fin, commentaire, enseignant) VALUES(?, ?, ?, ?, ?, ?)');
            $req->execute(array($etudiantId, $mdsId, $dateDebut, $dateFin, $commentaire, $_SESSION['idUser']));
        }
        function updtStage($etudiantId, $enseignantId, $mdsId, $dateDebut, $dateFin, $commentaire, $id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE stages SET etudiant = ?, mds = ?, date_debut = ?, date_fin = ?, commentaire = ?, enseignant = ? WHERE id = ?');
            $req->execute(array($etudiantId, $mdsId, $dateDebut, $dateFin, $commentaire, $enseignantId, $id));
        }
        function delStage($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE stages SET actif = 0 WHERE id = ?');
            $req->execute(array($id));
        }
    }