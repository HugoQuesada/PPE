<?php
    class manageEtudiants{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function getEtudiants(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM etudiants WHERE actif = 1 ORDER BY nom ASC, promo DESC');
            return $req;
        }
        function getEtudiant($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT * FROM etudiants WHERE id = ?');
            $req->execute(array($id));
            return $req;
        }
        function getEtudiantsTab(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM etudiants WHERE actif = 1 ORDER BY nom ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom']));
            }
            return $tab;
        }
        function getEtudiantsName(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT nom, prenom FROM etudiants WHERE actif = 1 ORDER BY nom ASC');
            return $req;
        }
        function addEtudiant($nom, $prenom, $option, $mail, $mobile, $promo){
            $bdd = $this->getDb();
            $req = $bdd->prepare('INSERT INTO etudiants(nom, prenom, optionSio, mail, mobile, promo) VALUES(?, ?, ?, ?, ?, ?)');
            $req->execute(array($nom, $prenom, $option, $mail, $mobile, $promo));
        }
        function updtEtudiant($nom, $prenom, $option, $mail, $mobile, $promo, $id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE etudiants SET nom = ?, prenom = ?, optionSio = ?, mail = ?, mobile = ?, promo = ? WHERE id = ?');
            $req->execute(array($nom, $prenom, $option, $mail, $mobile, $promo, $id));
        }
        function activeEtudiant($nom, $prenom, $option, $mail, $mobile, $promo){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE etudiants SET optionSio = ?, mail = ?, mobile = ?, promo = ?, actif = 1 WHERE nom = ? and prenom = ?');
            $req->execute(array($option, $mail, $mobile, $promo, $nom, $prenom));
        }
        function delEtudiant($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE etudiants SET actif = 0 WHERE id = ?');
            $req->execute(array($id));
        }
        function getEtudiantId($nom){
            $temp = explode(' ', $nom);
            $nom = $temp[0];
            $prenom = $temp[1];
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT id, nom, prenom FROM etudiants WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
            while($data = $req->fetch()){$id = $data['id'];}
            return $id;
        }
        function issetEtudiant($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT id, nom FROM etudiants WHERE id = ?');
            $req->execute(array($id));
            $isset = false;
            while($data = $req->fetch()){$isset = true;}
            return $isset;
        }
        function existEtudiant($nom, $prenom){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT nom, prenom FROM etudiants WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
            $exist = false;
            while($data = $req->fetch()){$exist = true;}
            return $exist;
        }  
        function activatedEtudiant($nom, $prenom){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE etudiants SET actif = 1 WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
        }
    }