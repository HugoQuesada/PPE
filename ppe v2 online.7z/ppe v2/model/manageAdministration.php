<?php
    class manageAdministration{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function getInfosSite(){
            $bdd = $this->getDb();
            $data['users'] = $bdd->query('SELECT COUNT(id) FROM users WHERE 1');
            while($temp = $data['users']->fetch()){
              $data['users'] = $temp[0];
              break;
            }
            $data['entreprises'] = $bdd->query('SELECT COUNT(id) FROM entreprises WHERE 1');
            while($temp = $data['entreprises']->fetch()){
              $data['entreprises'] = $temp[0];
              break;
            }
            $data['etudiants'] = $bdd->query('SELECT COUNT(id) FROM etudiants WHERE 1');
            while($temp = $data['etudiants']->fetch()){
              $data['etudiants'] = $temp[0];
              break;
            }
            $data['mds'] = $bdd->query('SELECT COUNT(id) FROM mds WHERE 1');
            while($temp = $data['mds']->fetch()){
              $data['mds'] = $temp[0];
              break;
            }
            $data['responsables'] = $bdd->query('SELECT COUNT(id) FROM responsables WHERE 1');
            while($temp = $data['responsables']->fetch()){
              $data['responsables'] = $temp[0];
              break;
            }
            $data['stages'] = $bdd->query('SELECT COUNT(id) FROM stages WHERE 1');
            while($temp = $data['stages']->fetch()){
              $data['stages'] = $temp[0];
              break;
            }
            return $data;
        }
        function getInfosSiteActif(){
            $bdd = $this->getDb();
            $data['users'] = $bdd->query('SELECT COUNT(id) FROM users WHERE actif = 1');
            while($temp = $data['users']->fetch()){
              $data['users'] = $temp[0];
              break;
            }
            $data['entreprises'] = $bdd->query('SELECT COUNT(id) FROM entreprises WHERE actif = 1');
            while($temp = $data['entreprises']->fetch()){
              $data['entreprises'] = $temp[0];
              break;
            }
            $data['etudiants'] = $bdd->query('SELECT COUNT(id) FROM etudiants WHERE actif = 1');
            while($temp = $data['etudiants']->fetch()){
              $data['etudiants'] = $temp[0];
              break;
            }
            $data['mds'] = $bdd->query('SELECT COUNT(id) FROM mds WHERE actif = 1');
            while($temp = $data['mds']->fetch()){
              $data['mds'] = $temp[0];
              break;
            }
            $data['responsables'] = $bdd->query('SELECT COUNT(id) FROM responsables WHERE actif = 1');
            while($temp = $data['responsables']->fetch()){
              $data['responsables'] = $temp[0];
              break;
            }
            $data['stages'] = $bdd->query('SELECT COUNT(id) FROM stages WHERE actif = 1');
            while($temp = $data['stages']->fetch()){
              $data['stages'] = $temp[0];
              break;
            }
            return $data;
        }
        function addUser($nom, $prenom, $mail, $mobile, $password, $statut){
          $bdd = $this->getDb();
          $req = $bdd->prepare('INSERT INTO users(nom, prenom, mail, mobile, password, statut) VALUES(?, ?, ?, ?, ?, ?)');
          $req->execute(array($nom, $prenom, $mail, $mobile, $password, $statut));
        }
        function updtUser($nom, $prenom, $mail, $mobile, $statut, $id){
          $bdd = $this->getDb();
          $req = $bdd->prepare('UPDATE users SET nom = ?, prenom = ?, mail = ?, mobile = ?, statut = ? WHERE id = ?');
          $req->execute(array($nom, $prenom, $mail, $mobile, $statut, $id));
        }
        function delUser($id){
          $bdd = $this->getDb();
          $req = $bdd->prepare('UPDATE users SET actif = 0 WHERE id = ?');
          $req->execute(array($id));
        }
        function activeUser($id){
          $bdd = $this->getDb();
          $req = $bdd->prepare('UPDATE users SET actif = 1 WHERE id = ?');
          $req->execute(array($id));
        }
        function getUsersActif(){
          $bdd = $this->getDb();
          $req = $bdd->prepare('SELECT * FROM users WHERE actif = 1 and id != ?');
          $req->execute(array($_SESSION['idUser']));
          return $req;
        }
        function getUsersInactif(){
          $bdd = $this->getDb();
          $req = $bdd->prepare('SELECT * FROM users WHERE actif = 0 and id != ?');
          $req->execute(array($_SESSION['idUser']));
          return $req;
        }
        function getUsers(){
          $bdd = $this->getDb();
          $req = $bdd->prepare('SELECT * FROM users WHERE id != ?');
          $req->execute(array($_SESSION['idUser']));
          return $req;
        }
        function getUser($id){
          $bdd = $this->getDb();
          $req = $bdd->prepare('SELECT * FROM users WHERE id = ?');
          $req->execute(array($id));
          return $req;
        }
        function changePasswordUser($pass, $id){
          $bdd = $this->getDb();
          $req = $bdd->prepare('UPDATE users SET password = ? WHERE id = ?');
          $req->execute(array($pass, $id));
        }
    }
