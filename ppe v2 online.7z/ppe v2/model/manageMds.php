<?php
    class manageMds{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function getMds(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM mds WHERE actif = 1 ORDER BY nom ASC');
            return $req;
        }
        function getRespMds(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM responsables WHERE actif = 1 and estMds = 1 ORDER BY nom ASC');
            return $req;
        }
        function getMdsOne($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT * FROM mds WHERE id = ?');
            $req->execute(array($id));
            return $req;
        }
        function getMdsTab(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM mds WHERE actif = 1 ORDER BY nom ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom']));
            }
            return $tab;
        }
        function getMdsEntreprise(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM mds WHERE actif = 1 ORDER BY nom ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = $data['entreprise'];
            }
            return $tab;
        }
        function getMdsRespEntreprise(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM responsables WHERE actif = 1 and estMds = 1 ORDER BY nom ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = $data['entreprise'];
            }
            return $tab;
        }
        function getMdsMobile(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT id, mobile FROM mds WHERE actif = 1 ORDER BY id ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = $data['mobile'];
            }
            return $tab;
        }
        function getMdsMail(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT id, mail FROM mds WHERE actif = 1 ORDER BY id ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = $data['mail'];
            }
            return $tab;
        }
        //Retourne un tableau avec pour cle le nom du mds et pour valeur son id
        function getMdsIdCle($req){
            $tab = array();
            while($data = $req->fetch()){
                $tab[ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom']))] = $data['id'];
            }
        }
        function getMdsName(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT nom, prenom FROM mds WHERE actif = 1 ORDER BY nom ASC');
            return $req;
        }
        function addMds($nom, $prenom, $mail, $mobile, $entrepriseId){
            $bdd = $this->getDb();
            $req = $bdd->prepare('INSERT INTO mds(nom, prenom, mail, mobile, entreprise) VALUES(?, ?, ?, ?, ?)');
            $req->execute(array($nom, $prenom, $mail, $mobile, $entrepriseId));
        }
        function updtMds($nom, $prenom, $mail, $mobile, $entrepriseId, $id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE mds SET nom = ?, prenom = ?, mail = ?, mobile = ?, entreprise = ? WHERE id = ?');
            $req->execute(array($nom, $prenom, $mail, $mobile, $entrepriseId, $id));
        }
        function activeMds($nom, $prenom, $mail, $mobile, $entrepriseId){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE mds SET mail = ?, mobile = ?, entreprise = ?, actif = 1 WHERE nom = ? and prenom = ?');
            $req->execute(array($mail, $mobile, $entrepriseId, $nom, $prenom));
        }
        function delMds($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE mds SET actif = 0 WHERE id = ?');
            $req->execute(array($id));
        }
        function getMdsId($nom){
            $temp = explode(' ', $nom);
            $nom = $temp[0];
            $prenom = $temp[1];
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT id, nom, prenom FROM mds WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
            while($data = $req->fetch()){$id = $data['id'];}
            return $id;
        }
        function existMds($nom, $prenom){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT nom, prenom FROM mds WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
            $exist = false;
            while($data = $req->fetch()){$exist = true;}
            return $exist;
        }
        function activatedMds($nom, $prenom){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE mds SET actif = 1 WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
        }
    }
