<?php
    class manageEntreprises{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function getEntreprisesTab(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM entreprises WHERE actif = 1 ORDER BY rs ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = ucwords(mb_strtolower($data['rs']));
            }
            return $tab;
        }
        function getEntreprises(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM entreprises WHERE actif = 1 ORDER BY rs ASC');
            return $req;
        }
        function getEntreprise($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT * FROM entreprises WHERE id = ? and actif = 1');
            $req->execute(array($id));
            return $req;
        }
        function getEntreprisesRs(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT rs FROM entreprises WHERE actif = 1 ORDER BY rs ASC');
            return $req;
        }
        function addEntreprise($rs, $mobile, $adresse, $horaires, $desc){
            $bdd = $this->getDb();
            $req = $bdd->prepare('INSERT INTO entreprises(rs, mobile, adresse, horaires, description) VALUES(?, ?, ?, ?, ?)');
            $req->execute(array($rs, $mobile, $adresse, $horaires, $desc));
        }
        function updtEntreprise($rs, $mobile, $adresse, $horaires, $desc, $id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE entreprises SET rs = ?, mobile = ?, adresse = ?, horaires = ?, description = ? WHERE id = ?');
            $req->execute(array($rs, $mobile, $adresse, $horaires, $desc, $id));
        }
        function activeEntreprise($rs, $mobile, $adresse, $horaires, $desc){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE entreprises SET mobile = ?, adresse = ?, horaires = ?, description = ?, actif = 1 WHERE rs = ?');
            $req->execute(array($mobile, $adresse, $horaires, $desc, $rs));
        }
        function delEntreprise($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE entreprises SET actif = 0 WHERE id = ?');
            $req->execute(array($id));
        }
        function getEntrepriseId($rs){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT id, rs FROM entreprises WHERE rs = ?');
            $req->execute(array($rs));
            while($data = $req->fetch()){$id = $data['id'];}
            return $id;
        }
        function getEntreprisesName(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT rs FROM entreprises WHERE actif = 1 ORDER BY rs ASC');
            return $req;
        }
        function existEntreprise($rs){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT rs FROM entreprises WHERE rs = ?');
            $req->execute(array($rs));
            $exist = false;
            while($data = $req->fetch()){$exist = true;}
            return $exist;
        }
        function activatedEntreprise($rs){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE entreprises SET actif = 1 WHERE rs = ?');
            $req->execute(array($rs));
        }
    }