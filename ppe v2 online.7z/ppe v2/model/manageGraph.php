<?php
    class manageGraph{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function getAll(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM stages');
            $dataChartTemp = $dataChart = array();
            while($data = $req->fetch()){
                $req2 = $bdd->prepare('SELECT * FROM mds WHERE id = ?');
                $req2->execute(array($data['mds']));
                while($data2 = $req2->fetch()){
                    $req3 = $bdd->prepare('SELECT * FROM entreprises WHERE id = ?');
                    $req3->execute(array($data2['entreprise']));
                    while($data3 = $req3->fetch()){
                        (isset($dataChartTemp[$data3['rs']]['value']))? $dataChartTemp[$data3['rs']]['value'] += 1 : $dataChartTemp[$data3['rs']]['value'] = 1;
                    }
                }
            }
            $i = 0;
            foreach ($dataChartTemp as $nom => $data) {
                foreach ($data as $key => $value) {
                    $dataChart[$i]['nom'] = $nom;
                    $dataChart[$i]['value'] = $value;
                    $i++;
                }
            }
            return $dataChart;
        }
        function getYear($year){
            $bdd = $this->getDb();
            $dataChartTemp = array();
            $dataChart = array();
            $req = $bdd->prepare('SELECT * FROM stages WHERE year(date_debut) = ?');
            $req->execute(array($year));
            while($data = $req->fetch()){
                $req2 = $bdd->prepare('SELECT * FROM mds WHERE id = ?');
                $req2->execute(array($data['mds']));
                while($data2 = $req2->fetch()){
                    $req3 = $bdd->prepare('SELECT * FROM entreprises WHERE id = ?');
                    $req3->execute(array($data2['entreprise']));
                    while($data3 = $req3->fetch()){
                        (isset($dataChartTemp[$data3['rs']]['value']))? $dataChartTemp[$data3['rs']]['value'] += 1 : $dataChartTemp[$data3['rs']]['value'] = 1;
                    }
                }
            }
            $i = 0;
            foreach ($dataChartTemp as $nom => $data) {
                foreach ($data as $key => $value) {
                    $dataChart[$i]['nom'] = $nom;
                    $dataChart[$i]['value'] = $value;
                    $i++;
                }
            }
            return $dataChart;
        }
        function getOption($option){
            $bdd = $this->getDb();
            $dataChartTemp = array();
            $dataChart = array();
            $req = $bdd->query('SELECT * FROM stages');
            while($data = $req->fetch()){
                $req2 = $bdd->prepare('SELECT * FROM etudiants WHERE id = ?');
                $req2->execute(array($data['etudiant']));
                while($data2 = $req2->fetch()){
                    $optionE = $data2['optionSio'];
                }
                if($optionE == $option){
                    $req2 = $bdd->prepare('SELECT * FROM mds WHERE id = ?');
                    $req2->execute(array($data['mds']));
                    while($data2 = $req2->fetch()){
                        $req3 = $bdd->prepare('SELECT * FROM entreprises WHERE id = ?');
                        $req3->execute(array($data2['entreprise']));
                        while($data3 = $req3->fetch()){
                            (isset($dataChartTemp[$data3['rs']]['value']))? $dataChartTemp[$data3['rs']]['value'] += 1 : $dataChartTemp[$data3['rs']]['value'] = 1;
                        }
                    }
                }
            }
            $i = 0;
            foreach ($dataChartTemp as $nom => $data) {
                foreach ($data as $key => $value) {
                    $dataChart[$i]['nom'] = $nom;
                    $dataChart[$i]['value'] = $value;
                    $i++;
                }
            }
            return $dataChart;
        }
        function getYearOption($year, $option){
            $bdd = $this->getDb();
            $dataChartTemp = array();
            $dataChart = array();
            $req = $bdd->prepare('SELECT * FROM stages WHERE year(date_debut) = ?');
            $req->execute(array($year));
            while($data = $req->fetch()){
                $req2 = $bdd->prepare('SELECT * FROM etudiants WHERE id = ?');
                $req2->execute(array($data['etudiant']));
                while($data2 = $req2->fetch()){
                    $optionE = $data2['optionSio'];
                }
                if($optionE == $option){
                    $req2 = $bdd->prepare('SELECT * FROM mds WHERE id = ?');
                    $req2->execute(array($data['mds']));
                    while($data2 = $req2->fetch()){
                        $req3 = $bdd->prepare('SELECT * FROM entreprises WHERE id = ?');
                        $req3->execute(array($data2['entreprise']));
                        while($data3 = $req3->fetch()){
                            (isset($dataChartTemp[$data3['rs']]['value']))? $dataChartTemp[$data3['rs']]['value'] += 1 : $dataChartTemp[$data3['rs']]['value'] = 1;
                        }
                    }
                }
            }
            $i = 0;
            foreach ($dataChartTemp as $nom => $data) {
                foreach ($data as $key => $value) {
                    $dataChart[$i]['nom'] = $nom;
                    $dataChart[$i]['value'] = $value;
                    $i++;
                }
            }
            return $dataChart;
        }
        function getPromo($promo){
            $bdd = $this->getDb();
            $dataChartTemp = array();
            $dataChart = array();
            $req = $bdd->query('SELECT * FROM stages');
            while($data = $req->fetch()){
                $req2 = $bdd->prepare('SELECT * FROM etudiants WHERE id = ?');
                $req2->execute(array($data['etudiant']));
                while($data2 = $req2->fetch()){
                    $promoE = $data2['promo'];
                }
                if($promoE == $promo){
                    $req2 = $bdd->prepare('SELECT * FROM mds WHERE id = ?');
                    $req2->execute(array($data['mds']));
                    while($data2 = $req2->fetch()){
                        $req3 = $bdd->prepare('SELECT * FROM entreprises WHERE id = ?');
                        $req3->execute(array($data2['entreprise']));
                        while($data3 = $req3->fetch()){
                            (isset($dataChartTemp[$data3['rs']]['value']))? $dataChartTemp[$data3['rs']]['value'] += 1 : $dataChartTemp[$data3['rs']]['value'] = 1;
                        }
                    }
                }
            }
            $i = 0;
            foreach ($dataChartTemp as $nom => $data) {
                foreach ($data as $key => $value) {
                    $dataChart[$i]['nom'] = $nom;
                    $dataChart[$i]['value'] = $value;
                    $i++;
                }
            }
            return $dataChart;
        }
        function getPromoYear($promo, $year){
            $bdd = $this->getDb();
            $dataChartTemp = array();
            $dataChart = array();
            $req = $bdd->prepare('SELECT * FROM stages WHERE year(date_debut) = ?');
            $req->execute(array($year));
            while($data = $req->fetch()){
                $req2 = $bdd->prepare('SELECT * FROM etudiants WHERE id = ?');
                $req2->execute(array($data['etudiant']));
                while($data2 = $req2->fetch()){
                    $promoE = $data2['promo'];
                }
                if($promoE == $promo){
                    $req2 = $bdd->prepare('SELECT * FROM mds WHERE id = ?');
                    $req2->execute(array($data['mds']));
                    while($data2 = $req2->fetch()){
                        $req3 = $bdd->prepare('SELECT * FROM entreprises WHERE id = ?');
                        $req3->execute(array($data2['entreprise']));
                        while($data3 = $req3->fetch()){
                            (isset($dataChartTemp[$data3['rs']]['value']))? $dataChartTemp[$data3['rs']]['value'] += 1 : $dataChartTemp[$data3['rs']]['value'] = 1;
                        }
                    }
                }
            }
            $i = 0;
            foreach ($dataChartTemp as $nom => $data) {
                foreach ($data as $key => $value) {
                    $dataChart[$i]['nom'] = $nom;
                    $dataChart[$i]['value'] = $value;
                    $i++;
                }
            }
            return $dataChart;
        }
        function getPromoOption($promo, $option){
            $bdd = $this->getDb();
            $dataChartTemp = array();
            $dataChart = array();
            $req = $bdd->query('SELECT * FROM stages');
            while($data = $req->fetch()){
                $req2 = $bdd->prepare('SELECT * FROM etudiants WHERE id = ?');
                $req2->execute(array($data['etudiant']));
                while($data2 = $req2->fetch()){
                    $promoE = $data2['promo'];
                    $optionE = $data2['optionSio'];
                }
                if($promoE == $promo and $optionE == $option){
                    $req2 = $bdd->prepare('SELECT * FROM mds WHERE id = ?');
                    $req2->execute(array($data['mds']));
                    while($data2 = $req2->fetch()){
                        $req3 = $bdd->prepare('SELECT * FROM entreprises WHERE id = ?');
                        $req3->execute(array($data2['entreprise']));
                        while($data3 = $req3->fetch()){
                            (isset($dataChartTemp[$data3['rs']]['value']))? $dataChartTemp[$data3['rs']]['value'] += 1 : $dataChartTemp[$data3['rs']]['value'] = 1;
                        }
                    }
                }
            }
            $i = 0;
            foreach ($dataChartTemp as $nom => $data) {
                foreach ($data as $key => $value) {
                    $dataChart[$i]['nom'] = $nom;
                    $dataChart[$i]['value'] = $value;
                    $i++;
                }
            }
            return $dataChart;
        }
        function getColors($tab){
            $colors = array();
            for($i = 0; $i < count($tab); $i++){
                $colors[] = rand(1, 40) * 6 . ',' . rand(1, 40) * 6 . ',' . rand(1, 40) * 6;
            }
            return $colors;
        }
        function getNb($tab){
            $nb = 0;
            for($i = 0; $i < count($tab); $i++){
                $nb += $tab[$i]["value"];
            }
            return $nb;
        }
    }
