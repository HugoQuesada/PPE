<?php
    class manageComptes{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function encode($think){
            return hash('sha256', $think);
        }
        function updtComptesMDP($nom, $prenom, $mail, $mobile, $pass){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE users SET nom = ?, prenom = ?, mail = ?, mobile = ?, password = ? WHERE id = ?');
            $req->execute(array($nom, $prenom, $mail, $mobile, $this->encode($pass), $_SESSION['idUser']));
        }
        function updtComptes($nom, $prenom, $mail, $mobile){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE users SET nom = ?, prenom = ?, mail = ?, mobile = ? WHERE id = ?');
            $req->execute(array($nom, $prenom, $mail, $mobile, $_SESSION['idUser']));
        }
        function getCompte(){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT * FROM users WHERE id = ?');
            $req->execute(array($_SESSION['idUser']));
            return $req;
        }
    }
