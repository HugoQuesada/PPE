<?php
    class manageTests{
        function testMail($mail){
            return filter_var($mail, FILTER_VALIDATE_EMAIL);
        }
        function testMobile($mobile){
            $valide = false;
            $cpt = 0;
            $temp = explode('.', $mobile);
            if(count($temp) == 3){
                for($i = 0; $i < 3; $i++){
                    (strlen($temp[$i]) == 2)? $cpt++ : $cpt = 0;
                }
                ($cpt == 3)? $valide = true: $valide = false;
            }
            return $valide;
        }
    }
