<?php
    class manageResponsables{
        function getDb(){
            $db = new PDO('mysql:host=mysql.hostinger.fr;dbname=u183378598_dcg;charset=utf8', 'u183378598_dgc', 'MeVxbyrp1M[Iby7>Rr');
            return $db;
        }
        function getResponsablesTab(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM responsables WHERE actif = 1 ORDER BY nom ASC');
            $tab = array();
            while($data = $req->fetch()){
                $tab[$data['id']] = ucwords(mb_strtolower($data['nom']));
            }
            return $tab;
        }
        function getResponsables(){
            $bdd = $this->getDb();
            $req = $bdd->query('SELECT * FROM responsables WHERE actif = 1 ORDER BY entreprise, nom ASC');
            return $req;
        }
        function getResponsable($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT * FROM responsables WHERE id = ?');
            $req->execute(array($id));
            return $req;
        }
        function addResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $estMds){
            $bdd = $this->getDb();
            $req = $bdd->prepare('INSERT INTO responsables(nom, prenom, civilite, fonction, mail, mobile, entreprise, estMds) VALUES(?, ?, ?, ?, ?, ?, ?, ?)');
            $req->execute(array($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, ($estMds == 'oui')));
        }
        function updtResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $id, $estMds){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE responsables SET nom = ?, prenom = ?, civilite = ?, fonction = ?, mail = ?, mobile = ?, entreprise = ?, estMds = ? WHERE id = ?');
            $req->execute(array($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, ($estMds == 'oui'), $id));
        }
        function activeResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $estMds){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE responsables SET civilite = ?, fonction = ?, mail = ?, mobile = ?, entreprise = ?, estMds = ?, actif = 1 WHERE nom = ? and prenom = ?');
            $req->execute(array($civilite, $fonction, $mail, $mobile, $entrepriseId, ($estMds == 'oui'), $nom, $prenom));
        }
        function activatedResponsable($nom, $prenom){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE responsables SET actif = 1 WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
        }
        function delResponsable($id){
            $bdd = $this->getDb();
            $req = $bdd->prepare('UPDATE responsables SET actif = 0 WHERE id = ?');
            $req->execute(array($id));
        }
        function existResponsable($nom, $prenom){
            $bdd = $this->getDb();
            $req = $bdd->prepare('SELECT nom, prenom FROM responsables WHERE nom = ? and prenom = ?');
            $req->execute(array($nom, $prenom));
            $exist = false;
            while($data = $req->fetch()){$exist = true;}
            return $exist;
        }
    }
