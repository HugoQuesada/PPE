<?php
    require_once('model/manageEntreprises.php');
    require_once('model/manageMds.php');

    function getMdsId($nom){
        $manageMds = new manageMds();
        return $manageMds->getMdsId($nom);
    }
    function viewMds(){
        $manageMds = new manageMds();
        $req = $manageMds->getMds();
        $req2 = $manageMds->getRespMds();
        $mdsEntreprises = $manageMds->getMdsEntreprise();
        $mdsRespEntreprises = $manageMds->getMdsRespEntreprise();

        $manageEntreprises = new manageEntreprises();
        $entreprises = $manageEntreprises->getEntreprisesTab();

        require('view/mdsView.php');
    }
    function addMdsForm(){
        $manageEntreprises = new manageEntreprises();
        $entreprises = $manageEntreprises->getEntreprisesRs();

        require('view/add/mdsFormAddView.php');
    }
    function addMds($nom, $prenom, $mail, $mobile, $entrepriseId){
        $manageMds = new manageMds();
        $mds = $manageMds->addMds($nom, $prenom, $mail, $mobile, $entrepriseId);

        header('Location: ./index.php?action=viewMds');
    }
    function viewMdsOne($id){
        $manageMds = new manageMds();
        $req = $manageMds->getMdsOne($id);
        $mdsEntreprises = $manageMds->getMdsEntreprise();

        $manageEntreprises = new manageEntreprises();
        $entreprisesName = $manageEntreprises->getEntreprisesName();
        $entreprises = $manageEntreprises->getEntreprisesTab();

        require('view/updt/mdsFormUpdtView.php');
    }
    function updtMds($nom, $prenom, $mail, $mobile, $entrepriseId, $id){
        $manageMds = new manageMds();
        $mds = $manageMds->updtMds($nom, $prenom, $mail, $mobile, $entrepriseId, $id);

        viewMds();
    }
    function delMds($id){
        $manageMds = new manageMds();
        $req = $manageMds->delMds($id);

        header('Location: ./index.php?action=viewMds');
    }
    function existMds($nom, $prenom){
        $manageMds = new manageMds();
        return $manageMds->existMds($nom, $prenom);
    }
    function activeMds($nom, $prenom, $mail, $mobile, $entrepriseId){
        $manageMds = new manageMds();
        $mds = $manageMds->activeMds($nom, $prenom, $mail, $mobile, $entrepriseId);

        header('Location: ./index.php?action=viewMds');
    }
    function activatedMds($nom, $prenom){
        $manageMds = new manageMds();
        $manageMds->activatedMds($nom, $prenom);

        header('Location: ./index.php?action=viewMds');
    }
