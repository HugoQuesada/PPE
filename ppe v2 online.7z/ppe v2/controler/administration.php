<?php
    require_once('model/manageAdministration.php');
    function viewAdministration(){
      $manageAdministration = new manageAdministration();
      $infos = $manageAdministration->getInfosSite();
      $infosActif = $manageAdministration->getInfosSiteActif();
      $req = $manageAdministration->getUsers();
      require('view/administrationView.php');
    }
    function addUserForm(){
      require('view/admin/userFormAddView.php');
    }
    function addUser($nom, $prenom, $mail, $mobile, $password, $statut){
      $manageAdministration = new manageAdministration();
      $manageAdministration->addUser($nom, $prenom, $mail, $mobile, $password, $statut);
    }
    function delUserForm(){
      $manageAdministration = new manageAdministration();
      $req = $manageAdministration->getUsersActif();
      require('view/admin/userFormDelView.php');
    }
    function delUser($id){
      $manageAdministration = new manageAdministration();
      $manageAdministration->delUser($id);
    }
    function activeUserForm(){
      $manageAdministration = new manageAdministration();
      $req = $manageAdministration->getUsersInactif();
      require('view/admin/userFormActivateView.php');
    }
    function activeUser($id){
      $manageAdministration = new manageAdministration();
      $manageAdministration->activeUser($id);
    }
    function updtUserForm($id){
      $manageAdministration = new manageAdministration();
      $req = $manageAdministration->getUser($id);
      require('view/admin/userFormUpdtView.php');
    }
    function updtUser($nom, $prenom, $mail, $mobile, $statut, $id){
      $manageAdministration = new manageAdministration();
      $manageAdministration->updtUser($nom, $prenom, $mail, $mobile, $statut, $id);
    }
    function changePasswordUser($pass, $id){
      $manageAdministration = new manageAdministration();
      $manageAdministration->changePasswordUser($pass, $id);
    }
