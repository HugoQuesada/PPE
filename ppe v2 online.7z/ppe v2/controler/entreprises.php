<?php
    require_once('model/manageEntreprises.php');

    //------DIVERS
    function getEntrepriseId($rs){
        $manageEntreprises = new manageEntreprises();
        return $manageEntreprises->getEntrepriseId($rs);
    }
    function viewEntreprises(){
        $manageEntreprises = new manageEntreprises();
        $req = $manageEntreprises->getEntreprises();

        require('view/entreprisesView.php');
    }
    function addEntrepriseForm(){
        require('view/add/entrepriseFormAddView.php');   
    }
    function addEntreprise($rs, $mobile, $adresse, $horaires, $desc){
        $manageEntreprises = new manageEntreprises();
        $manageEntreprises->addEntreprise($rs, $mobile, $adresse, $horaires, $desc);
        $_SESSION['NewEntreprise'] = $rs;
        header('Location: ./index.php?action=addMdsForm');
    }
    function activeEntreprise($rs, $mobile, $adresse, $horaires, $desc){
        $manageEntreprises = new manageEntreprises();
        $manageEntreprises->activeEntreprise($rs, $mobile, $adresse, $horaires, $desc);
        header('Location: ./index.php?action=viewEntreprises');
    }
    function viewEntreprise($id){
        $manageEntreprises = new manageEntreprises();
        $req = $manageEntreprises->getEntreprise($id);

        require('view/updt/entrepriseFormUpdtView.php');
    }
    function updtEntreprise($rs, $mobile, $adresse, $horaires, $desc, $id){
        $manageEntreprises = new manageEntreprises();
        $manageEntreprises->updtEntreprise($rs, $mobile, $adresse, $horaires, $desc, $id);

        header('Location: ./index.php?action=viewEntreprises');
    }
    function delEntreprise($id){
        $manageEntreprises = new manageEntreprises();
        $req = $manageEntreprises->delEntreprise($id);

        header('Location: ./index.php?action=viewEntreprises');
    }
    function existEntreprise($rs){
        $manageEntreprises = new manageEntreprises();
        return $manageEntreprises->existEntreprise($rs);
    }
    function activatedEntreprise($rs){
        $manageEntreprises = new manageEntreprises();
        $manageEntreprises->activatedEntreprise($rs);

        header('Location: ./index.php?action=viewEntreprises');
    }