<?php
    $title = "Stages";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item active dropdown show">
        <a class="nav-link dropdown-toggle" href="" id="dropdownStage" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Stages</a>
        <div class="dropdown-menu" aria-labelledby="dropdownStage">
            <a class="dropdown-item" href="./index.php?action=addStageForm">Ajout d'un stages</a>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Stages</h1>
    <div class="table-view">
        <table id="table" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Etudiant</th>
                <th>Entreprise</th>
                <th>Maitre de stage</th>
                <th>Mobile</th>
                <th>Mail</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($data = $req->fetch()){
                    echo('<tr class="tr-cursor" onclick="document.location=\'./index.php?action=viewStage&id=' . $data['id'] . '\'">
                        <td>' . $etudiants[$data['etudiant']] . '</td>
                        <!-- $mdsEntreprises est un tableau qui retourne l\'id de l\'entreprise en fonction de l\'id du mds -->
                        <td>' . $entreprises[$mdsEntreprises[$data['mds']]] . '</td>
                        <td>' . $mds[$data['mds']] . '</td>
                        <td>' . $mobile[$data['mds']] . '</td>
                        <td>' . $mail[$data['mds']] . '</td>
                    </tr>');
                }
            ?>
        </tbody>
        </table>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
