<?php
    $title = "Menu";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Modification d'un Maitre de stages</h1>
    <div class="container-form">
        <?php
            while($data = $req->fetch()){
            ?>
                <form action="./index.php?action=updtMds" method="POST" class="col-5">
                    <div class="form-group">
                        <h5>Nom</h5>
                        <input type="text" class="form-control" id="nom" name="nom" disabled="disabled" value="<?= $data['nom']; ?>">
                    </div>
                    <div class="form-group">
                        <h5>Prenom</h5>
                        <input type="text" class="form-control" id="prenom" name="prenom" disabled="disabled" value="<?= $data['prenom']; ?>">
                    </div>
                    <div class="form-group">
                        <h5>Mail</h5>
                        <input type="email" class="form-control" id="mail" name="mail" disabled="disabled" value="<?= $data['mail']; ?>">
                    </div>
                    <div class="form-group">
                        <h5>Mobile</h5>
                        <input type="tel" class="form-control" id="mobile" name="mobile" placeholder="xx.xx.xx" disabled="disabled" value="<?= $data['mobile']; ?>">
                    </div>
                    <div class="form-group">
                        <h5>Entreprise</h5>
                        <input type="text" class="form-control" id="entreprise" name="entreprise" list="listEntreprises" disabled="disabled" value="<?= $entreprises[$mdsEntreprises[$data['id']]] ?>">
                        <datalist id="listEntreprises">
                            <?php
                                while($data2 = $entreprisesName->fetch()){
                                    echo('<option value="' . ucwords(mb_strtolower($data2['rs'])) . '"></option>');
                                }
                            ?>
                        </datalist>
                    </div>
                    <div class="form-group">
                        <input type="text" name="id" value="<?= $_GET['id']; ?>" hidden>
                        <input type="submit" id="submit" class="btn btn-primary form-control" hidden>
                        <a class="btn btn-primary form-control" id="modif">Modifier</a>
                        <a class="btn btn-danger form-control" id="suppr">Supprimer</a>
                    </div>
                </form>
            <?php
            }
        ?>
    </div>
</div>
<?php
    $content = ob_get_clean();
    $link = "./index.php?action=delMds&id=" . $_GET['id'];
    ob_start();
?>
<script>
    $(document).ready(function() {
      $('#suppr').click(function(){
        $('#buttonConfirm').trigger("click");
      });
      $('#modif').click(function(){
          $('.form-control').prop('disabled', false);
          $('#submit').prop('hidden', false);
          $('#modif').prop('hidden', true);
          $('#suppr').prop('hidden', true);
      });
    });
</script>
<?php
    $script = ob_get_clean();
    require("template.php");
?>
