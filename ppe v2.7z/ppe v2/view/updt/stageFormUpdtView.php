<?php
    $title = "Menu";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Modification d'un stage</h1>
    <div class="container-form">
        <?php
            while($data = $req->fetch()){
                ?>
                <form action="./index.php?action=updtStage" method="POST" class="col-5">
                    <div class="form-group">
                        <h5>Etudiant</h5>
                        <input type="text" class="form-control" id="etudiant" name="etudiant" list="listEtudiants" disabled="disabled" value="<?= ucwords($etudiants[$data['etudiant']]); ?>">
                        <datalist id="listEtudiants">
                            <?php
                                while($data2 = $etudiantsName->fetch()){
                                    echo('<option value="' . ucwords(mb_strtolower($data2['nom'] . ' ' . $data2['prenom'])) . '"></option>');
                                }
                            ?>
                        </datalist>
                    </div>
                    <div class="form-group">
                        <h5>Maitre de stage</h5>
                        <input type="text" class="form-control" id="mds" name="mds" list="listMDS" disabled="disabled" value="<?= ucwords(mb_strtolower($mds[$data['mds']])); ?>">
                        <datalist id="listMDS">
                            <?php
                                while($data2 = $mdsName->fetch()){
                                    echo('<option value="' . ucwords(mb_strtolower($data2['nom'] . ' ' . $data2['prenom'])) . '"></option>');
                                }
                            ?>
                        </datalist>
                    </div>
                    <div class="form-group">
                        <h5>Enseignant responsable du suivi</h5>
                        <input type="text" class="form-control" id="enseignant" name="enseignant" list="listEnseignants" disabled="disabled" value="<?= ucwords(mb_strtolower($enseignant[$data['enseignant']])); ?>">
                        <datalist id="listEnseignants">
                            <?php
                                while($data2 = $enseignantsName->fetch()){
                                    echo('<option value="' . ucwords(mb_strtolower($data2['nom'] . ' ' . $data2['prenom'])) . '"></option>');
                                }
                            ?>
                        </datalist>
                    </div>
                    <div class="form-group">
                        <h5>Date de debut</h5>
                        <input type="date" class="form-control" id="dateDebut" name="dateDebut" disabled="disabled" value="<?= $data['date_debut']; ?>">
                    </div>
                    <div class="form-group">
                        <h5>Date de fin</h5>
                        <input type="date" class="form-control" id="dateFin" name="dateFin" disabled="disabled" value="<?= $data['date_fin']; ?>">
                    </div>
                    <div class="form-group">
                        <h5>Commentaire</h5>
                        <textarea name="commentaire" id="textarea" cols="55" rows="5" disabled="disabled"><?= $data['commentaire']; ?></textarea>
                    </div>
                    <div class="form-group">
                        <input type="text" name="id" value="<?= $_GET['id']; ?>" hidden>
                        <input type="submit" id="submit" class="btn btn-primary form-control" hidden>
                        <a class="btn btn-primary form-control" id="modif">Modifier</a>
                        <a class="btn btn-danger form-control" id="suppr">Supprimer</a>
                    </div>
                </form>
            <?php
            }
        ?>
    </div>
</div>
<?php
    $content = ob_get_clean();
    $link = "./index.php?action=delStage&id=" . $_GET['id'];
    ob_start();
?>
<script>
    $(document).ready(function() {
      $('#suppr').click(function(){
        $('#buttonConfirm').trigger("click");
      });
      $('#modif').click(function(){
          $('.form-control').prop('disabled', false);
          $('#textarea').prop('disabled', false);
          $('#submit').prop('hidden', false);
          $('#modif').prop('hidden', true);
          $('#suppr').prop('hidden', true);
      });
    });
</script>
<?php
    $script = ob_get_clean();
    require("template.php");
?>
