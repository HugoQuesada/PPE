<?php
    $title = "Menu";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Modification d'une Entreprise</h1>
    <div class="container-form">
        <?php
            while($data = $req->fetch()){
                ?>
                <form action="./index.php?action=updtEntreprise" method="POST" class="col-5">
                    <div class="form-group">
                        <h5>Raison Sociale</h5>
                        <input type="text" class="form-control" id="rs" name="rs" disabled="disabled" value="<?= ucwords($data['rs']); ?>">
                    </div>
                    <div class="form-group">
                        <h5>Adresse</h5>
                        <input type="text" class="form-control" id="adresse" name="adresse" disabled="disabled" value="<?= ucwords($data['adresse']); ?>">
                    </div>
                    <div class="form-group">
                        <h5>Mobile</h5>
                        <input type="tel" class="form-control" id="mobile" name="mobile" placeholder="xx.xx.xx" disabled="disabled" value="<?= ucwords($data['mobile']); ?>">
                    </div>
                    <div class="form-group">
                        <h5>Horaires</h5>
                        <input type="text" class="form-control" id="horaires" name="horaires" placeholder="Ex: 8h-12h / 13h-17h" disabled="disabled" value="<?= ucwords($data['horaires']); ?>">
                    </div>
                    <div class="form-group">
                        <h5>Description</h5>
                        <textarea name="description" id="textarea" cols="55" rows="5" disabled="disabled"><?= $data['description']; ?></textarea>
                    </div>
                    <div class="form-group">
                        <input type="text" name="id" value="<?= $_GET['id']; ?>" hidden>
                        <input type="submit" id="submit" class="btn btn-primary form-control" hidden>
                        <a class="btn btn-primary form-control" id="modif">Modifier</a>
                        <a class="btn btn-danger form-control" id="suppr">Supprimer</a>
                    </div>
                </form>
            <?php
            }
        ?>
    </div>
</div>
<?php
    $content = ob_get_clean();
    $link = "./index.php?action=delEntreprise&id=" . $_GET['id'];
    ob_start();
?>
<script>
    $(document).ready(function() {
      $('#suppr').click(function(){
        $('#buttonConfirm').trigger("click");
      });
      $('#modif').click(function(){
          $('.form-control').prop('disabled', false);
          $('#textarea').prop('disabled', false);
          $('#submit').prop('hidden', false);
          $('#modif').prop('hidden', true);
          $('#suppr').prop('hidden', true);
      });
    });
</script>
<?php
    $script = ob_get_clean();
    require("template.php");
?>
