<?php
    $title = "Responsables";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item active dropdown show">
        <a class="nav-link dropdown-toggle" href="" id="dropdownResponsable" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">Responsables</a>
        <div class="dropdown-menu" aria-labelledby="dropdownResponsable">
            <a class="dropdown-item" href="./index.php?action=addResponsableForm">Ajout d'un responsable</a>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Responsables</h1>
    <div class="table-view">
        <table id="table" class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>Entreprise</th>
                <th>Identité</th>
                <th>Fonction</th>
                <th>Mail</th>
                <th>Mobile</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($data = $req->fetch()){
                    echo('<tr class="tr-cursor" onclick="document.location=\'./index.php?action=viewResponsable&id=' . $data['id'] . '\'">
                        <td>' . ucwords(mb_strtolower($entreprises[$data['entreprise']])) . '</td>
                        <td>' . ucwords($data['civilite'] . '. ' . mb_strtolower($data['nom'] . ' ' . $data['prenom'])) . '</td>
                        <td>' . ucfirst(mb_strtolower($data['fonction'])) . '</td>
                        <td>' . $data['mail'] . '</td>
                        <td>' . $data['mobile'] . '</td>
                    </tr>');
                }
            ?>
        </tbody>
        </table>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
