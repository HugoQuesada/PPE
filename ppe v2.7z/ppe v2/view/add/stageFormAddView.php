<?php
    $title = "Stages";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Ajout d'un stage</h1>
    <div class="container-form">
        <form action="./index.php?action=addStage" method="POST" class="col-5">
            <div class="form-group">
                <h5>Etudiant</h5>
                <input type="text" class="form-control" id="etudiant" name="etudiant" list="listEtudiants">
                <datalist id="listEtudiants">
                    <?php
                        while($data = $etudiants->fetch()){
                            echo('<option value="' . ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom'])) . '"></option>');
                        }
                    ?>
                </datalist>
            </div>
            <div class="form-group">
                <h5>Maitre de stage</h5>
                <input type="text" class="form-control" id="mds" name="mds" list="listMDS">
                <datalist id="listMDS">
                    <?php
                        while($data = $mds->fetch()){
                            echo('<option value="' . ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom'])) . '"></option>');
                        }
                    ?>
                </datalist>
            </div>
            <div class="form-group">
                <h5>Date de debut</h5>
                <input type="date" class="form-control" id="dateDebut" name="dateDebut">
            </div>
            <div class="form-group">
                <h5>Date de fin</h5>
                <input type="date" class="form-control" id="dateFin" name="dateFin">
            </div>
            <div class="form-group">
                <h5>Commentaire</h5>
                <textarea name="commentaire" cols="55" rows="5"></textarea>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary form-control">
            </div>
        </form>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
