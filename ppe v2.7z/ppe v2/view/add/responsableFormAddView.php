<?php
    $title = "Responsables";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Ajout d'un Responsable</h1>
    <div class="container-form">
        <form action="./index.php?action=addResponsable" method="POST" class="col-5">
            <div class="form-group">
                <h5>Nom</h5>
                <input type="text" class="form-control" id="nom" name="nom">
            </div>
            <div class="form-group">
                <h5>Prenom</h5>
                <input type="text" class="form-control" id="prenom" name="prenom">
            </div>
            <div class="form-group">
                <h5>Civilité</h5>
                <select name="civilite" class="form-control">
                    <option value="m">M.</option>
                    <option value="mme">Mme.</option>
                </select>
            </div>
            <div class="form-group">
                <h5>Fonction</h5>
                <input type="text" class="form-control" id="fonction" name="fonction">
            </div>
            <div class="form-group">
                <h5>Mail</h5>
                <input type="email" class="form-control" id="mail" name="mail">
            </div>
            <div class="form-group">
                <h5>Mobile</h5>
                <input type="tel" class="form-control" id="mobile" name="mobile" placeholder="xx.xx.xx">
            </div>
            <div class="form-group">
                <h5>Entreprise</h5>
                <input type="text" class="form-control" id="entreprise" name="entreprise" list="listEntreprises">
                <datalist id="listEntreprises">
                    <?php
                        while($data = $entreprises->fetch()){
                            echo('<option value="' . ucwords(mb_strtolower($data['rs'])) . '"></option>');
                        }
                    ?>
                </datalist>
            </div>
            <h5>Est maitre de stage ?</h5>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="estMds" id="ouiMds" value="oui">
              <label class="form-check-label" for="inlineRadio1">Oui</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="radio" name="estMds" id="nonMds" value="non">
              <label class="form-check-label" for="inlineRadio2">Non</label>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary form-control">
            </div>
        </form>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
