<?php
    $title = "Graphiques";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template starter-template-comptes">
    <h1>Statistiques</h1>
    <h6>Stages trouvés : <?= $nbStages; ?></h6>
    <div class="chart-container" style="height:70%; width:100%">
        <canvas id="myChart"></canvas>
    </div>
</div>
<?php
    $content = ob_get_clean();
    ob_start();
?>
<script src="public/js/chart.min.js"></script>
<script>
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: [<?php
            $init = true;
            for($i = 0; $i < count($dataChart); $i++){
                if($init){
                    $init = false;
                    echo('"' . ucwords($dataChart[$i]["nom"]) . '"');
                }else{
                    echo(', "' . ucwords($dataChart[$i]["nom"]) . '"');
                }
            }
            ?>],
        datasets: [{
            label: 'Nombre de stagiaires <?= ucwords($option); ?> en <?= $year; ?> par entreprises',
            data: [<?php
            $init = true;
            for($i = 0; $i < count($dataChart); $i++){
                if($init){
                    $init = false;
                    echo($dataChart[$i]["value"]);
                }else{
                    echo(', ' . $dataChart[$i]["value"] . '');
                }
            }
            ?>],
            backgroundColor: [
                <?php
                    $init = true;
                    for($i = 0; $i < count($colors); $i++){
                        if($init){
                            $init = false;
                            echo('\'rgba(' . $colors[$i] . ', 0.2)\'');
                        }else{
                            echo(', \'rgba(' . $colors[$i] . ', 0.2)\'');
                        }
                    }
                ?>
            ],
            borderColor: [
                <?php
                    $init = true;
                    for($i = 0; $i < count($colors); $i++){
                        if($init){
                            $init = false;
                            echo('\'rgba(' . $colors[$i] . ', 1)\'');
                        }else{
                            echo(', \'rgba(' . $colors[$i] . ', 1)\'');
                        }
                    }
                ?>
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true,
                    stepSize: 1
                }
            }]
        }
    }
});
</script>
<?php
    $script = ob_get_clean();
    require("template.php");
?>
