<?php
    $title = "Graphiques";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template starter-template-comptes">
    <h1>Statistiques</h1>
    <div class="container-form">
        <div class="list-group" id="graph-list">
            <a class="list-group-item active" href="">Choix du graphique de statistique</a>
            <a class="list-group-item list-group-item-action" href="./index.php?action=graph&type=1">Tout les stages</a>
            <a class="list-group-item list-group-item-action" id="a-year">Stages par année</a>
            <a class="list-group-item list-group-item-action" id="a-option">Stage par option</a>
            <a class="list-group-item list-group-item-action" id="a-year-option">Stage par année et option</a>
            <a class="list-group-item list-group-item-action" id="a-promotion">Stage par promotion</a>
            <a class="list-group-item list-group-item-action" id="a-promotion-year">Stage par promotion et par année</a>
            <a class="list-group-item list-group-item-action" id="a-promotion-option">Stage par promotion et par option</a>
        </div>
    </div>
</div>
<?php
    $content = ob_get_clean();
    ob_start();
?>
<script>
    $(document).ready(function() {
      $('#a-year').click(function(){
        $('#buttonYear').trigger("click");
      });
      $('#a-option').click(function(){
        $('#buttonOption').trigger("click");
      });
      $('#a-year-option').click(function(){
        $('#buttonYearOption').trigger("click");
      });
      $('#a-promotion').click(function(){
        $('#buttonPromo').trigger("click");
      });
      $('#a-promotion-year').click(function(){
        $('#buttonPromoYear').trigger("click");
      });
      $('#a-promotion-option').click(function(){
        $('#buttonPromoOption').trigger("click");
      });
    });
</script>
<?php
    $script = ob_get_clean();
    require("template.php");
?>
