<?php
    $title = "Connexion";
    ob_start();
?>
<ul class="navbar-nav mr-auto">
    <li class="nav-item active">
        <a class="nav-link" href="#">Connexion <span class="sr-only">(current)</span></a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Connexion</h1>
    <div class="row">
        <div class="col-4"></div>
        <form action="./index.php?action=connect" method="POST" class="col-4">
            <div class="form-group">
                <h5>Nom d'utilisateur</h5>
                <input type="text" class="form-control" id="username" name="username">
            </div>
            <div class="form-group">
                <h5>Mot de passe</h5>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary form-control">
            </div>
        </form>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>