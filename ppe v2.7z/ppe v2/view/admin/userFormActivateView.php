<?php
    $title = "Menu";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item active">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>

    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Activation d'un utilisateur</h1>
    <div class="container-form">
        <form id="form" method="GET" class="col-5">
            <div class="form-group">
                <h5>Utilisateur</h5>
                <select type="text" class="form-control" id="user" name="user">
                    <?php
                      while($data = $req->fetch()){
                        echo('<option value="' . $data['id'] . '">' . ucwords(mb_strtolower($data['nom'] . ' ' . $data['prenom'])) . '</option>');
                      }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary form-control" hidden>
                <a class="btn btn-primary form-control" id="suppr">Activer</a>
            </div>
        </form>
    </div>
</div>
<?php
    $content = ob_get_clean();
    ob_start();
?>
<script>
    $(document).ready(function() {
      $('#suppr').click(function(){
        $('#buttonConfirm').trigger("click");
      });
      $('#validation').click(function(){
        var url = "./index.php?action=activeUser&id=" + $("#user").val();
        event.preventDefault();
        window.location = url;
      });
    });
</script>
<?php
    $script = ob_get_clean();
    require("template.php");
?>
