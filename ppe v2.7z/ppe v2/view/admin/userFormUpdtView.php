<?php
    $title = "Etudiants";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item active">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>

    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template">
    <h1>Ajout d'un utilisateur</h1>
    <div class="container-form">
        <?php
            while($data = $req->fetch()){
                ?>
                    <form action="./index.php?action=updtUser" method="POST" class="col-5">
                        <div class="form-group">
                            <h5>Nom</h5>
                            <input type="text" class="form-control" id="nom" name="nom" value="<?= ucwords($data['nom']); ?>">
                        </div>
                        <div class="form-group">
                            <h5>Prenom</h5>
                            <input type="text" class="form-control" id="prenom" name="prenom" value="<?= ucwords($data['prenom']); ?>">
                        </div>
                        <div class="form-group">
                            <h5>Mail</h5>
                            <input type="email" class="form-control" id="mail" name="mail" value="<?= $data['mail']; ?>">
                        </div>
                        <div class="form-group">
                            <h5>Mobile</h5>
                            <input type="tel" class="form-control" id="mobile" name="mobile" placeholder="xx.xx.xx" value="<?= $data['mobile']; ?>">
                        </div>
                        <div class="form-group">
                            <h5>Statut</h5>
                            <select type="text" class="form-control" id="statut" name="statut">
                                <option value="prof" <?php echo(($data['statut'] == "prof")? 'selected': ''); ?>>Professeur</option>
                                <option value="admin" <?php echo(($data['statut'] == "admin")? 'selected': ''); ?>>Administrateur</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <input type="text" name="id" value="<?= $_GET['id']; ?>" hidden>
                            <input type="submit" id="submit" class="btn btn-primary form-control" value="Modifier">
                        </div>
                    </form>
                    <form action="./index.php?action=changePasswordUser" method="POST" class="col-5">
                        <div class="form-group">
                            <h5>Nouveau mot de passe</h5>
                            <input type="password" class="form-control" id="password" name="password">
                        </div>
                        <div class="form-group">
                            <input type="text" name="id" value="<?= $_GET['id']; ?>" hidden>
                            <input type="submit" class="btn btn-danger form-control" value="Changer le mot de passe">
                        </div>
                    </form>
                <?php
            }
        ?>
    </div>
</div>
<?php
    $content = ob_get_clean();
    $script = "";
    require("template.php");
?>
