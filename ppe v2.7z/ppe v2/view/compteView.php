<?php
    $title = "Comptes";
    ob_start();
?>
<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link" href="./index.php">Accueil <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewStages">Stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEntreprises">Entreprises</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewResponsables">Responsables</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewMDS">Maitres de stages</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=viewEtudiants">Etudiants</a>
    </li>
    <li class="nav-item active">
        <a class="nav-link" href="./index.php?action=account">Compte</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=bdd">Base de données</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=graph">Statistiques</a>
    </li>
    <?php
      if(isset($_SESSION['admin'])){
        if($_SESSION['admin'] == true){
          echo('
          <li class="nav-item">
              <a class="nav-link" href="./index.php?action=admin">Administration</a>
          </li>');
        }
      }
    ?>
    
    <li class="nav-item">
        <a class="nav-link" href="./index.php?action=deconnect">Deconnexion</a>
    </li>
</ul>
<?php
    $menu = ob_get_clean();
    ob_start();
?>
<div class="starter-template starter-template-comptes">
    <h1>Gestion du compte</h1>
    <div class="container-form">
        <?php
        while($data = $comptes->fetch()){
        ?>
            <form id="comptes-form" action="./index.php?action=updtCompte" method="POST" class="col-5">
                <div class="form-group">
                    <h5>Nom</h5>
                    <input type="text" class="form-control" id="nom" name="nom" value="<?= $data['nom']; ?>">
                </div>
                <div class="form-group">
                    <h5>Prenom</h5>
                    <input type="text" class="form-control" id="prenom" name="prenom" value="<?= $data['prenom']; ?>">
                </div>
                <div class="form-group">
                    <h5>Mail</h5>
                    <input type="email" class="form-control" id="mail" name="mail" value="<?= $data['mail']; ?>">
                </div>
                <div class="form-group">
                    <h5>Mobile</h5>
                    <input type="tel" class="form-control" id="mobile" name="mobile" placeholder="xx.xx.xx" value="<?= $data['mobile']; ?>">
                </div>
                <div class="alert alert-info" role="alert">
                    <strong>INFORMATION: </strong>Ne remplir les champs ci-dessous que pour modifier le mot de passe.
                </div>
                <div class="form-group">
                    <h5>Ancien Mot de passe</h5>
                    <input type="password" class="form-control" id="oldpass" name="oldpass">
                </div>
                <div class="form-group">
                    <h5>Nouveau Mot de passe</h5>
                    <input type="password" class="form-control" id="newpass" name="newpass">
                </div>
                <div class="form-group">
                    <h5>Confirmer le Mot de passe</h5>
                    <input type="password" class="form-control" id="confirmpass" name="confirmpass">
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary form-control">
                </div>
            </form>
            <?php
        }
        ?>
    </div>
</div>
<?php
    $content = ob_get_clean();
    require("template.php");
?>
