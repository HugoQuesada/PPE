<?php
    require_once('model/manageComptes.php');
    function viewComptes(){
        $manageComptes = new manageComptes();
        $comptes = $manageComptes->getCompte();

        require('view/compteView.php');
    }
    function updtCompteMDP($nom, $prenom, $mail, $mobile, $pass){
        $manageComptes = new manageComptes();
        $manageComptes->updtComptesMDP($nom, $prenom, $mail, $mobile, $pass);

        header('Location: ./index.php?action=account');
    }
    function updtCompte($nom, $prenom, $mail, $mobile){
        $manageComptes = new manageComptes();
        $manageComptes->updtComptes($nom, $prenom, $mail, $mobile);

        header('Location: ./index.php?action=account');
    }