<?php
    require_once('model/manageEtudiants.php');

    function getEtudiantId($nom){
        $manageEtudiants = new manageEtudiants();
        return $manageEtudiants->getEtudiantId($nom);
    }
    function issetEtudiant($id){
        $manageEtudiants = new manageEtudiants();
        return $manageEtudiants->issetEtudiant($id);
    }
    function viewEtudiants(){
        $manageEtudiants = new manageEtudiants();
        $req = $manageEtudiants->getEtudiants();

        require('view/etudiantsView.php');
    }
    function addEtudiantForm(){
        require('view/add/etudiantFormAddView.php');   
    }
    function addEtudiant($nom, $prenom, $option, $mail, $mobile, $promo){
        $manageEtudiants = new manageEtudiants();
        $etudiants = $manageEtudiants->addEtudiant($nom, $prenom, $option, $mail, $mobile, $promo);

        header('Location: ./index.php?action=viewEtudiants');  
    }
    function viewEtudiant($id){
        $manageEtudiants = new manageEtudiants();
        $req = $manageEtudiants->getEtudiant($id);

        require('view/updt/etudiantFormUpdtView.php');
    }
    function updtEtudiant($nom, $prenom, $option, $mail, $mobile, $promo, $id){
        $manageEtudiants = new manageEtudiants();
        $etudiants = $manageEtudiants->updtEtudiant($nom, $prenom, $option, $mail, $mobile, $promo, $id);

        header('Location: ./index.php?action=viewEtudiants');  
    }
    function delEtudiant($id){
        $manageEtudiants = new manageEtudiants();
        $req = $manageEtudiants->delEtudiant($id);

        header('Location: ./index.php?action=viewEtudiants');
    }
    function existEtudiant($nom, $prenom){
        $manageEtudiants = new manageEtudiants();
        return $manageEtudiants->existEtudiant($nom, $prenom);
    }
    function activeEtudiant($nom, $prenom, $option, $mail, $mobile, $promo){
        $manageEtudiants = new manageEtudiants();
        $etudiants = $manageEtudiants->activeEtudiant($nom, $prenom, $option, $mail, $mobile, $promo);

        header('Location: ./index.php?action=viewEtudiants'); 
    }
    function activatedEtudiant($nom, $prenom){
        $manageEtudiants = new manageEtudiants();
        $etudiants = $manageEtudiants->activatedEtudiant($nom, $prenom);

        header('Location: ./index.php?action=viewEtudiants'); 
    }