<?php
    require_once('model/manageBdd.php');
    function dumpBdd($action){
        $manageBdd = new manageBdd();
        $manageBdd->dumpBdd($action);

        require('view/bddView.php');
    }
    function viewBdd(){
        require('view/bddView.php');
    }