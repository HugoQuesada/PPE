<?php
    require_once('model/manageEntreprises.php');
    require_once('model/manageResponsables.php');

    function viewResponsables(){
        $manageResponsables = new manageResponsables();
        $req = $manageResponsables->getResponsables();

        $manageEntreprises = new manageEntreprises();
        $entreprises = $manageEntreprises->getEntreprisesTab();

        require('view/responsablesView.php');
    }
    function addResponsableForm(){
        $manageEntreprises = new manageEntreprises();
        $entreprises = $manageEntreprises->getEntreprisesRs();

        require('view/add/responsableFormAddView.php');
    }
    function addResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $estMds){
        $manageResponsables = new manageResponsables();
        $manageResponsables->addResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $estMds);

        header('Location: ./index.php?action=viewResponsables');
    }
    function viewResponsable($id){
        $manageResponsables = new manageResponsables();
        $req = $manageResponsables->getResponsable($id);

        $manageEntreprises = new manageEntreprises();
        $entreprises = $manageEntreprises->getEntreprisesTab();
        $entreprisesName = $manageEntreprises->getEntreprisesName();

        require('view/updt/responsableFormUpdtView.php');
    }
    function updtResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $id, $estMds){
        $manageResponsables = new manageResponsables();
        $manageResponsables->updtResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $id, $estMds);

        header('Location: ./index.php?action=viewResponsables');
    }
    function delResponsable($id){
        $manageResponsables = new manageResponsables();
        $req = $manageResponsables->delResponsable($id);

        header('Location: ./index.php?action=viewResponsables');
    }
    function existResponsable($nom, $prenom){
        $manageResponsables = new manageResponsables();
        return $manageResponsables->existResponsable($nom, $prenom);
    }
    function activeResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $estMds){
        $manageResponsables = new manageResponsables();
        $manageResponsables->activeResponsable($nom, $prenom, $civilite, $fonction, $mail, $mobile, $entrepriseId, $estMds);

        header('Location: ./index.php?action=viewResponsables');
    }
    function activatedResponsable($nom, $prenom){
        $manageResponsables = new manageResponsables();
        $manageResponsables->activatedResponsable($nom, $prenom);

        header('Location: ./index.php?action=viewResponsables');
    }
