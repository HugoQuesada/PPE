<?php
    require_once('model/manageGraph.php');

    function viewGraph(){
        require('view/graph/graphView.php');
    }
    function graphAll(){
        $manageGraph = new manageGraph();
        $dataChart = $manageGraph->getAll();
        $colors = $manageGraph->getColors($dataChart);
        $nbStages = $manageGraph->getNb($dataChart);

        require('view/graph/graphAllView.php');
    }
    function graphYear($year){
        $manageGraph = new manageGraph();
        $dataChart = $manageGraph->getYear($year);
        $colors = $manageGraph->getColors($dataChart);
        $nbStages = $manageGraph->getNb($dataChart);

        require('view/graph/graphYearView.php');
    }
    function graphOption($option){
        $manageGraph = new manageGraph();
        $dataChart = $manageGraph->getOption($option);
        $colors = $manageGraph->getColors($dataChart);
        $nbStages = $manageGraph->getNb($dataChart);

        require('view/graph/graphOptionView.php');
    }
    function graphYearOption($year, $option){
        $manageGraph = new manageGraph();
        $dataChart = $manageGraph->getYearOption($year, $option);
        $colors = $manageGraph->getColors($dataChart);
        $nbStages = $manageGraph->getNb($dataChart);

        require('view/graph/graphYearOptionView.php');
    }
    function graphPromo($promo){
        $manageGraph = new manageGraph();
        $dataChart = $manageGraph->getPromo($promo);
        $colors = $manageGraph->getColors($dataChart);
        $nbStages = $manageGraph->getNb($dataChart);

        require('view/graph/graphPromoView.php');
    }
    function graphPromoYear($promo, $year){
        $manageGraph = new manageGraph();
        $dataChart = $manageGraph->getPromoYear($promo, $year);
        $colors = $manageGraph->getColors($dataChart);
        $nbStages = $manageGraph->getNb($dataChart);

        require('view/graph/graphPromoYearView.php');
    }
    function graphPromoOption($promo, $option){
        $manageGraph = new manageGraph();
        $dataChart = $manageGraph->getPromoOption($promo, $option);
        $colors = $manageGraph->getColors($dataChart);
        $nbStages = $manageGraph->getNb($dataChart);

        require('view/graph/graphPromoOptionView.php');
    }
