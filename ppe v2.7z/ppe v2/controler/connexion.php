<?php
    require_once('model/manageConnexion.php');

    function connect($username, $password){
        $manageConnexion = new manageConnexion();
        return $manageConnexion->connect($username, $password);
    }
    function deconnect(){
        $manageConnexion = new manageConnexion();
        $manageConnexion->deconnect();
    }
    function connectForm(){
        require('view/connexionView.php');
    }
    function checkPass($pass){
        $manageConnexion = new manageConnexion();
        return $manageConnexion->checkPass($pass);
    }
    function encodePass($pass){
        $manageConnexion = new manageConnexion();
        return $manageConnexion->encode($pass);
    }
