<?php
    require_once('model/manageUsers.php');
    require_once('model/manageEtudiants.php');
    require_once('model/manageEntreprises.php');
    require_once('model/manageMds.php');
    require_once('model/manageStages.php');
    
    function getEnseignantId($name){
        $manageUsers = new manageUsers();
        return $manageUsers->getUsersId($name);
    }
    function viewStages(){
        $manageStages = new manageStages();
        $req = $manageStages->getStages();

        $manageEtudiants = new manageEtudiants();
        $etudiants = $manageEtudiants->getEtudiantsTab();

        $manageMds = new manageMds();
        $mds = $manageMds->getMdsTab();
        $mdsEntreprises = $manageMds->getMdsEntreprise();
        $mobile = $manageMds->getMdsMobile();
        $mail = $manageMds->getMdsMail();

        $manageEntreprises = new manageEntreprises();
        $entreprises = $manageEntreprises->getEntreprisesTab();

        require('view/stagesView.php');
    }
    function addStageForm(){
        $manageMds = new manageMds();
        $mds = $manageMds->getMdsName();

        $manageEtudiants = new manageEtudiants();
        $etudiants = $manageEtudiants->getEtudiantsName();

        require('view/add/stageFormAddView.php');   
    }
    function addStage($etudiantId, $mdsId, $dateDebut, $dateFin, $commentaire){
        $manageStages = new manageStages();
        $manageStages->addStage($etudiantId, $mdsId, $dateDebut, $dateFin, $commentaire);

        header('Location: ./index.php?action=viewStages');
    }
    function viewStage($id){
        $manageStages = new manageStages();
        $req = $manageStages->getStage($id);

        $manageEtudiants = new manageEtudiants();
        $etudiants = $manageEtudiants->getEtudiantsTab();
        $etudiantsName = $manageEtudiants->getEtudiantsName();

        $manageMds = new manageMds();
        $mds = $manageMds->getMdsTab();
        $mdsName = $manageMds->getMdsName();

        $manageUsers = new manageUsers();
        $enseignant = $manageUsers->getUsersTab();
        $enseignantsName = $manageUsers->getUsersName();

        $manageEntreprises = new manageEntreprises();
        $entreprises = $manageEntreprises->getEntreprisesTab();

        require('view/updt/stageFormUpdtView.php');
    }
    function updtStage($etudiantId, $enseignantId, $mdsId, $dateDebut, $dateFin, $commentaire, $id){
        $manageStages = new manageStages();
        $manageStages->updtStage($etudiantId, $enseignantId, $mdsId, $dateDebut, $dateFin, $commentaire, $id);

        header('Location: ./index.php?action=viewStages');
    }
    function delStage($id){
        $manageStages = new manageStages();
        $req = $manageStages->delStage($id);

        header('Location: ./index.php?action=viewStages');
    }