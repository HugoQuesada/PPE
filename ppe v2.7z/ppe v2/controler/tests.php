<?php
    require_once('model/manageTests.php');
    //------LES TESTS
    function testMail($mail){
        $manageTests = new manageTests();
        return $manageTests->testMail($mail);
    }
    function testMobile($mobile){
        $manageTests = new manageTests();
        return $manageTests->testMobile($mobile);
    }
