<?php
    function home(){
        require('view/homeView.php');
    }
